package com.example.tugaspraktikum;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Main4Activity extends AppCompatActivity {

    private EditText berat_badan, tinggi_badan;
    private Button btnHitung;
    private TextView hasil ;
    private TextView bmi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        berat_badan = (EditText) findViewById(R.id.berat_badan);
        tinggi_badan = (EditText) findViewById(R.id.tinggi_badan);
        btnHitung = (Button) findViewById(R.id.btn_hitung);
        hasil = (TextView) findViewById(R.id.hasil);
        bmi = (TextView) findViewById(R.id.bmi);

        getSupportActionBar().setTitle("Hitung Luas Persegi Panjang");

        btnHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String bb, tb;
                bb = berat_badan.getText().toString();
                tb = tinggi_badan.getText().toString();
                if (TextUtils.isEmpty(bb)) {
                    berat_badan.setError("Tidak Boleh Kosong!!!");
                    berat_badan.requestFocus();
                    Toast.makeText(getApplicationContext(),"gagal",Toast.LENGTH_LONG).show();
                } else if (TextUtils.isEmpty(tb)) {
                    tinggi_badan.setError("Tidak Boleh Kosong!!!");
                    tinggi_badan.requestFocus();
                    Toast.makeText(getApplicationContext(),"gagal",Toast.LENGTH_LONG).show();
                } else {
                    double b = Double.parseDouble(bb);
                    double t = Double.parseDouble(tb)/100;
                    double hasilBMI = b/(t*t);
                    Toast.makeText(getApplicationContext(),"berhasil",Toast.LENGTH_LONG).show();


                    if (hasilBMI < 18.5 ){
                        bmi.setText("UnderWeight");
                        hasil.setText("Hasil  : " + hasilBMI);

                    } else if  (hasilBMI >= 18.5 && hasilBMI <= 24.9){
                        bmi.setText("Normal Weight");
                        hasil.setText("Hasil  : " + hasilBMI);

                    } else if (hasilBMI >= 25 && hasilBMI <= 29.9) {
                        bmi.setText("over");
                        hasil.setText("Hasil  : " + hasilBMI);

                    } else if (hasilBMI >= 30 && hasilBMI <= 34.9) {
                        bmi.setText("obsity 1");
                        hasil.setText("Hasil : " + hasilBMI);

                    } else if (hasilBMI >= 35 && hasilBMI <= 39.9) {
                        bmi.setText("obsity 2");
                        hasil.setText("Hasil : " + hasilBMI);

                    } else if (hasilBMI >= 40) {
                        bmi.setText("obsity 3");
                        hasil.setText("Hasil : " + hasilBMI);
                    }
                }

            }
        });
    }
}