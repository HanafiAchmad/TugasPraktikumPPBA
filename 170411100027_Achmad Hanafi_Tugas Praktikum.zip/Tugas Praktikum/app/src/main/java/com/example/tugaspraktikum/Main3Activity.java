package com.example.tugaspraktikum;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tugaspraktikum.R;

public class Main3Activity extends AppCompatActivity {
    EditText nama;
    Button klik;
    TextView muncul;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        nama = findViewById(R.id.editText);
        klik = findViewById(R.id.button);
        muncul = findViewById(R.id.textView);
        klik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String vNama = nama.getText().toString();
                muncul.setText("Nama :"+vNama);

                Toast.makeText(getApplicationContext(),"Nama : "+vNama,Toast.LENGTH_LONG).show();

            }
        });

    }


}
